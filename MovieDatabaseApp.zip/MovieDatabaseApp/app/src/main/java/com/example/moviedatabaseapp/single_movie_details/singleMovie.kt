package com.example.moviedatabaseapp.single_movie_details

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.moviedatabaseapp.R

class singleMovie : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_single_movie)
    }
}
